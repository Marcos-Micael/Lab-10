package Conta;

public interface Tributavel {
	double calculaTributos();
}
